package dataStructure;

public enum AnalysisSafetyResult {
    UNSAFE,
    SAFE,
    UNKNOWN,
}
