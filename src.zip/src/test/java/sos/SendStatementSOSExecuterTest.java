package sos;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SendStatementSOSExecuterTest {
    private SendStatementSOSExecuter sendStatementSOSExecuter;

    @BeforeEach
    void setUp() { this.sendStatementSOSExecuter = new SendStatementSOSExecuter(); }


}