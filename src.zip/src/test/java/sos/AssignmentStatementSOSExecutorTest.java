package sos;

import static org.junit.jupiter.api.Assertions.*;

class AssignmentStatementSOSExecutorTest {



}